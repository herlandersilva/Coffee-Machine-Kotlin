package outcomes.separate_package.no_fallback_to_class_package;

class Main {
    public static void main(String[] args) {
        System.out.print("Class with main method");
    }
}
