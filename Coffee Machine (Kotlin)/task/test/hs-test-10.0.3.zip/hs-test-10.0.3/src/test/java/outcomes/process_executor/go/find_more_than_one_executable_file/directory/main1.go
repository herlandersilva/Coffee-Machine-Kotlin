package main

import "fmt"

func main() {
	fmt.Println(`First file`)
}
