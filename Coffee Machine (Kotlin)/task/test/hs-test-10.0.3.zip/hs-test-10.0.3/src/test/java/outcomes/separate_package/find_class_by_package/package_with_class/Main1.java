package outcomes.separate_package.find_class_by_package.package_with_class;

class Main1 {
    public static void main(String[] args) {
        System.out.print("Class by package");
    }
}
