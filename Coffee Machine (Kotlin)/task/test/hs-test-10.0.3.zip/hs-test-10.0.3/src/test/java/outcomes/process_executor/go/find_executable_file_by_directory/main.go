package main

import "fmt"

func main() {
	fmt.Println(`Main file`)
}