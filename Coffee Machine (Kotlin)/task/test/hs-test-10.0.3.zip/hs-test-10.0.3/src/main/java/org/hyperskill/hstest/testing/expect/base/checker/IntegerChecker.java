package org.hyperskill.hstest.testing.expect.base.checker;

public interface IntegerChecker {
    boolean check(int value);
}
