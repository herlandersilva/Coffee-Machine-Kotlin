package org.hyperskill.hstest.exception.testing;

public class TestedProgramThrewException extends Error {
}
