package org.hyperskill.hstest.testing.expect.base.checker;

public interface NumberChecker {
    boolean check(Number value);
}
