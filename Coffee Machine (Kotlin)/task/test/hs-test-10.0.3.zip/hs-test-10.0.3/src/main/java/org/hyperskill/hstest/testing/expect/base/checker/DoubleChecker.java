package org.hyperskill.hstest.testing.expect.base.checker;

public interface DoubleChecker {
    boolean check(double value);
}
