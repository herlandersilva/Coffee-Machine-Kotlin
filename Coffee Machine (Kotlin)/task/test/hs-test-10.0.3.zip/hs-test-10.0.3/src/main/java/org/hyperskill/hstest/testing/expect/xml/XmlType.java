package org.hyperskill.hstest.testing.expect.xml;

enum XmlType {

}
