package org.hyperskill.hstest.exception.testing;

public class InfiniteLoopException extends Error {
    public InfiniteLoopException(String msg) {
        super(msg);
    }
}
