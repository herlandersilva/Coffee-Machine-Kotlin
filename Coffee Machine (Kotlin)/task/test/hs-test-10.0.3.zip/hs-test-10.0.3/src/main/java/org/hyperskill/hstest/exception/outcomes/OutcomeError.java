package org.hyperskill.hstest.exception.outcomes;

public class OutcomeError extends Error {
    OutcomeError() {

    }

    OutcomeError(String message) {
        super(message);
    }
}
