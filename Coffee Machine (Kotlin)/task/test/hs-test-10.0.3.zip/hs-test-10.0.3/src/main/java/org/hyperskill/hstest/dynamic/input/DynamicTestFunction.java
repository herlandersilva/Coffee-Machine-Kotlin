package org.hyperskill.hstest.dynamic.input;

import java.util.function.Supplier;

public interface DynamicTestFunction extends Supplier<String> {
}
