package org.hyperskill.hstest.exception.testing;

public class TestedProgramFinishedEarly extends Error {
}
