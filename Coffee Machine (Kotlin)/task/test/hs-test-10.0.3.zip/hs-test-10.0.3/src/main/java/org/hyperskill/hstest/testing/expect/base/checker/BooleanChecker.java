package org.hyperskill.hstest.testing.expect.base.checker;

public interface BooleanChecker {
    boolean check(boolean value);
}
