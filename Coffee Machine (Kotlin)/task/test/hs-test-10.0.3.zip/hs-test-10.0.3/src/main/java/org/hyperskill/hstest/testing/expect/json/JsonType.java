package org.hyperskill.hstest.testing.expect.json;

enum JsonType {
    ANY, OBJECT, ARRAY, STRING, NUMBER, INTEGER, DOUBLE, BOOLEAN, NULL
}
