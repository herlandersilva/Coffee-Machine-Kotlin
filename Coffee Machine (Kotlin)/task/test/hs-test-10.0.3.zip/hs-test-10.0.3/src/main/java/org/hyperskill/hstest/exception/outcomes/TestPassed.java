package org.hyperskill.hstest.exception.outcomes;

public class TestPassed extends OutcomeError {
}
